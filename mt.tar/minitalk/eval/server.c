#include "minitalk.h"

t_chr   g_chr;

static void	server_handler(int sig, siginfo_t *siginfo, void *oldact)
{
	//static int				i = 0;
    //static unsigned char	c = 0;



	(void)oldact;
	g_chr.c |= (sig == SIGUSR2);
	if (++g_chr.i == 8)
	{
		g_chr.i = 0;
		if (!g_chr.c)
		{
			send_sig(siginfo->si_pid, SIGUSR2);
			return ;
		}
		ft_putchar(g_chr.c);
		g_chr.c = 0;
		send_sig(siginfo->si_pid, SIGUSR1);
	}
	else
		g_chr.c <<= 1;
}

int	main(void)
{
	struct sigaction	sig;

    g_chr.i = 0;
    g_chr.c = 0;
	ft_putstr("Server PID: ");
	ft_putnbr(getpid());
	ft_putchar('\n');
	sig.sa_sigaction = server_handler;
	sig.sa_flags = SA_SIGINFO;
	if (sigaction(SIGUSR1, &sig, 0) == -1 ||
	    sigaction(SIGUSR2, &sig, 0) == -1)
    {
      write(2, "Sigaction error\n", 16);
      exit(1);
    }
	while (1)
		pause();
	return (0);
}
